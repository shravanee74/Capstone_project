const express = require('express');
const sql = require('mssql');

const app = express();

const config = {
    user: 'sa',
    password: '0987654321',
    server: 'localhost',
    port: 1433,
    database: 'village_db',
    options: {
        trustServerCertificate: true
    }
};

// Connect DB
sql.connect(config)
.then(() => console.log("Connected to DB"))
.catch(err => console.log("DB Connection Failed:", err));

// API 1: States
app.get('/states', async (req, res) => {
    try {
        const result = await sql.query`
            SELECT state_id, state_name, state_code
            FROM states
        `;
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

// Start Server
app.listen(3000, () => {
    console.log("Server running on port 3000");
});


app.get('/districts', async (req, res) => {
    const { state_code } = req.query;

    try {
        const result = await sql.query`
            SELECT d.district_id, d.district_name
            FROM districts d
            JOIN states s ON d.state_id = s.state_id
            WHERE s.state_code = ${state_code}
            ORDER BY d.district_name
        `;
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});


app.get('/subdistricts', async (req, res) => {
    const { district_id } = req.query;

    try {
        const result = await sql.query`
            SELECT subdistrict_id, subdistrict_name
            FROM subdistricts
            WHERE district_id = ${district_id}
            ORDER BY subdistrict_name
        `;
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});


app.get('/villages', async (req, res) => {
    const { search } = req.query;

    try {
        const result = await sql.query`
            SELECT TOP 20 village_name, village_code
            FROM villages
            WHERE village_name LIKE ${search + '%'}
            ORDER BY village_name
        `;
        res.json(result.recordset);
    } catch (err) {
        res.status(500).send(err.message);
    }
});


const validateApiKey = async (req, res, next) => {
    const apiKey = req.headers['x-api-key'];

    if (!apiKey) {
        return res.status(403).json({ error: "API Key required" });
    }

    try {
        const result = await sql.query`
            SELECT * FROM api_clients
            WHERE api_key = ${apiKey}
        `;

        if (result.recordset.length === 0) {
            return res.status(401).json({ error: "Invalid API Key" });
        }

        next();
    } catch (err) {
        res.status(500).send(err.message);
    }
};